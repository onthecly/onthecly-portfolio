Portfolio Contents:

1. API Book Proposal - my tool and content strategy proposal from last year; main focus 
was new collaboration options with our SW team.

2. Golf Pick Ems - MBA/IT database class project. Wrote Oracle DB used for fantasy golf league
Web app. Created from scratch in 7 weeks.

3. Telecommuting - proposal made to Dell management team to give contractors same telecommuting
benefits as full-time employees.

4. My github - set up a repo, and posted my portfolio: https://github.com/onthecly/onthecly-portfolio